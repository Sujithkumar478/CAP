﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMEXCEPTION
{
    public class AM_EXCEPTION:ApplicationException
    {
        public AM_EXCEPTION()
        {
        }

        public AM_EXCEPTION(string message) : base(message)
        {
        }
    }
}
