﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMENTITY
{
    /// <summary>
    /// information required to the company
    /// </summary>
    [Serializable]
    public class AM_ENTITY
    {
        public string CoupounCode { get; set; }
        public string UserName { get; set; }
        public DateTime RedeemDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public double RedeemAmount { get; set; }
        public string ProductCode { get; set; }
        public double ProductPrice { get; set; }


    }
}
