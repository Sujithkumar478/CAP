﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMENTITY;
using AMDAL;
using AMEXCEPTION;
using System.Text.RegularExpressions;

namespace AMBLL
{
    public class AM_BLL
    {
        static AM_DAL customerDAL = new AM_DAL();

        /// <summary>
        /// validating the customer 
        /// </summary>
        /// <param name="customer"></param>
        /// <returns></returns>
        private static bool ValidateCustomer(AM_ENTITY customer)
        {
            bool ValidateCustomer = true;
            StringBuilder message = new StringBuilder();
            if ((customer.CoupounCode == string.Empty || customer.CoupounCode == null) || !Regex.IsMatch(customer.CoupounCode, @"[A-Z]{8}$"))
            {
                message.Append(Environment.NewLine + "Invalid Coupoun   Code");
                ValidateCustomer = false;
            }
            if ((customer.UserName == string.Empty || customer.UserName == null) || customer.UserName.Length<=30)
            {
                message.Append(Environment.NewLine + "Invalid Dealer Id");
                ValidateCustomer = false;
            }
            if (customer.RedeemDate < customer.ExpiryDate)
            {
                message.Append(Environment.NewLine + "Expired the coupoun code");
                ValidateCustomer = false;
            }
            if (customer.ProductPrice > 20000)
            {
                message.Append(Environment.NewLine + "you have to perchase more than 20000");
                ValidateCustomer = false;
            }
            if (customer.ProductCode == string.Empty || customer.ProductCode == null )
            {
                message.Append(Environment.NewLine + "Invalid Phone Number");
                ValidateCustomer = false;
            }
            

            if (ValidateCustomer == false)
            {
                throw new AM_EXCEPTION(message.ToString());
            }









            return ValidateCustomer;
        }

        public List<AM_ENTITY> SearchByCustomerValid(string CoupounCode)
        {
            return customerDAL.SearchByValidCustomerDAL(CoupounCode);
        }






        public bool InsertCustomerBll(AM_ENTITY newCustomer)
        {
            bool isCustomerAdded = false;
            if (ValidateCustomer(newCustomer))
            {
                isCustomerAdded = customerDAL.InsertCustomerDAL(newCustomer);
            }


            return isCustomerAdded;
        }

        /// <summary>
        /// serializing the customer
        /// </summary>
        /// <returns></returns>

        public bool SerializeCustomersBLL()
        {
            return customerDAL.SerializeCustomersDAL();
        }

        /// <summary>
        /// deserialization of customers in collections
        /// </summary>
        /// <returns></returns>

        public List<AM_ENTITY> DeserializeDealersBLL()
        {
            return customerDAL.DeserializeCustomersDAL();
        }
    }
}
