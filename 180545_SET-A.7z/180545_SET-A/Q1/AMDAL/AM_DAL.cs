﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMENTITY;
using AMEXCEPTION;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
namespace AMDAL
{
    public class AM_DAL
    {
        public static List<AM_ENTITY> Customers = new List<AM_ENTITY>();
        public bool InsertCustomerDAL(AM_ENTITY newCustomer)
        {

            bool isCustomerAdded = false;
            try
            {
                Customers.Add(newCustomer);
                isCustomerAdded = true;
            }
            catch (SystemException exception)
            {
                throw new AM_EXCEPTION(exception.Message);

            }

            return isCustomerAdded;

        }

        public List<AM_ENTITY> SearchByValidCustomerDAL(string CoupounCode)
        {
            return Customers.FindAll(customer => customer.CoupounCode.Equals(CoupounCode));
        }

        public bool SerializeCustomersDAL()
        {
            bool areCustomersSerialized = false;
            try
            {
                FileStream fileStream = new FileStream("CouponCodesData.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(fileStream, Customers);
                fileStream.Close();
                areCustomersSerialized = true;
            }
            catch (SystemException exception)
            {
                throw new AM_EXCEPTION(exception.Message);

            }
            return areCustomersSerialized;


        }

        public List<AM_ENTITY> DeserializeCustomersDAL()
        {
            List<AM_ENTITY> DeserializeCustomers = null;
            try
            {
                FileStream fileStream = new FileStream("CouponCodesData.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                DeserializeCustomers = binaryFormatter.Deserialize(fileStream) as List<AM_ENTITY>;
                fileStream.Close();
            }
            catch (AM_EXCEPTION exception)
            {

                throw new AM_EXCEPTION(exception.Message);

            }
            return DeserializeCustomers;
        }

       


       

    }
}
