﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMENTITY;
using AMBLL;
using AMEXCEPTION;
/// <summary>
/// Author:sujithkumar channa
/// </summary>
namespace AMPL
{
    class Program
    {
        static AM_BLL CustomerBLL = new AM_BLL();

        private static void PrintMenu()
        {

            Console.WriteLine("\n***********Amazon Customer System ***********");
            Console.WriteLine("1. INSERT The Customer DATA");
            Console.WriteLine( "2.Search offer Available to particular customer");
           
            Console.WriteLine("3. Serialize  ");
            Console.WriteLine("4. DeSerialize ");
          
           
            Console.WriteLine("********************************\n");
        }
        /// <summary>
        /// inserting the customer details
        /// </summary>
        private static void InsertCustomerPL()
        {
            try
            {
                //Acept input from user 
                Console.Write("Enter Customer Coupoun Code:");
                string CoupounCode = Console.ReadLine();
                Console.Write("Enter User Name:");
                string UserName = Console.ReadLine();

                Console.Write("Enter Customer Redeem date:");
                DateTime RedeemDate =Convert.ToDateTime( Console.ReadLine());
                Console.Write("Enter Customer Expiry date:");
                DateTime ExpiryDate = Convert.ToDateTime(Console.ReadLine());

                Console.Write("Enter customer Redeem Amount:");
                double RedeemAmount = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter customer ProductCode");
                string ProductCode = Console.ReadLine();
                Console.WriteLine("Enter product price");
                double ProductPrice = Convert.ToDouble(Console.ReadLine());



                //Pass input to create new object

                AM_ENTITY newCustomer = new AM_ENTITY();
                newCustomer.CoupounCode = CoupounCode;
                newCustomer.UserName = UserName;
                newCustomer.RedeemDate = RedeemDate;
                newCustomer.ExpiryDate = ExpiryDate;
                newCustomer.RedeemAmount = RedeemAmount;
                newCustomer.ProductCode = ProductCode;
                newCustomer.ProductPrice = ProductPrice;


                bool isNewCustomerAdded = CustomerBLL.InsertCustomerBll(newCustomer);
                if (isNewCustomerAdded)
                {
                    Console.WriteLine("Customer Details Inserted Sucuessfully");
                }
                else
                {
                    Console.WriteLine("Failed to Insert ");
                }


            }
            catch (AM_EXCEPTION exception)
            {
                Console.WriteLine("EXCEPTION OCCURED" + exception.Message);
            }
        }

        public static void SearchByCustomerValidPL()
        {
            Console.WriteLine("Enter your CoupounCode");
            string CoupounCode = Console.ReadLine();
            List<AM_ENTITY> searchedCustomers = CustomerBLL.SearchByCustomerValid(CoupounCode);
           
            Console.WriteLine("-----------------------------------------");
            Console.WriteLine("Customer coupoun code" + "\t" + "User Name " + "\t" +
                "Customer Redeem date" + "\t" + "Customer Expirary date" + "\t" + " Redeem AMount" +
                 "\t" + "Product Code" + "\t" + "Customer product Price");
            Console.WriteLine("--------------------------------------");

            foreach (AM_ENTITY customer in searchedCustomers)
            {
                Console.WriteLine(customer.CoupounCode + "\t" + customer.UserName + "\t" + customer.RedeemDate + "\t" + customer.ExpiryDate + "\t"
                    + customer.RedeemAmount + "\t" + customer.ProductCode);
            }


        }

        private static void SerializeCustomerPL()
        {
            if (CustomerBLL.SerializeCustomersBLL())
            {
                Console.WriteLine("Serialize customer details added sucuessfully");
            }
            else
            {
                Console.WriteLine("Failed to added Customer details");
            }

        }

        private static void DeserializeCustomerPL()
        {
            List<AM_ENTITY> DeserializedDealers = CustomerBLL.DeserializeDealersBLL();
            Console.WriteLine("Deserialised Data");

            Console.WriteLine("-----------------------------------------");
            Console.WriteLine("Customer coupoun code" + "\t" + "User Name " + "\t" +
                "Customer Redeem date" + "\t" + "Customer Expirary date" + "\t" + " Redeem AMount" +
                 "\t" + "Product Code" + "\t" + "Customer product Price");
            Console.WriteLine("--------------------------------------");
            foreach (AM_ENTITY customer in DeserializedDealers)
            {
                Console.WriteLine(customer.CoupounCode + "\t" + customer.UserName + "\t" + customer.RedeemDate + "\t" + customer.ExpiryDate + "\t"
                   + customer.RedeemAmount + "\t" + customer.ProductCode);
            }
            Console.WriteLine("---------------------------");

        }




        /// <summary>
        /// taking the user choices
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            byte choice;
            do
            {

                PrintMenu();
                Console.WriteLine("Enter your choice:");
                bool checkchoice;
                checkchoice = byte.TryParse(Console.ReadLine(), out choice);
                if (!checkchoice) { Console.WriteLine("Invalid Input"); }
               
                switch (choice)
                {
                    case 1:
                        InsertCustomerPL();

                        break;
                    case 2:
                        SearchByCustomerValidPL();
                        

                        break;



                    case 3:
                        SerializeCustomerPL();

                        break;
                    case 4:
                       DeserializeCustomerPL();

                        break;
                    


                    default:

                        break;

                }

            } while (choice != 0);
        }
    }
    
}
