﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class EntityClass
    {
        /// <summary>
        /// properties for reflection
        /// </summary>


        public string CoupounCode { get; set; }
        public string UserName { get; set; }
        public string RedeemDate { get; set; }
        public string ExpiryDate { get; set; }
        public double RedeemAmount { get; set; }
        public string ProductCode { get; set; }
        public double ProductPrice { get; set; }
        /// <summary>
        /// Parameter constructor for reflection
        /// </summary>
        /// <param name="CoupounCode"></param>
        /// <param name="UserName"></param>
        /// <param name="RedeemDate"></param>
        /// <param name="ExpiryDate"></param>
        /// <param name="RedeemAmount"></param>
        /// <param name="ProductCode"></param>
        /// <param name="ProductPrice"></param>

        public EntityClass( string CoupounCode,string UserName,string RedeemDate,string ExpiryDate,double RedeemAmount,  string ProductCode,double ProductPrice)

        {
            this.CoupounCode = CoupounCode;
            this.UserName = UserName;
            this.RedeemDate = RedeemDate;
            this.ExpiryDate = ExpiryDate;
            this.RedeemAmount = RedeemAmount;
            this.ProductCode = ProductCode;
            this.ProductPrice = ProductPrice;
        }
        public string GetEmpInfo()
        {
            return $"Coupoun code:{CoupounCode},User Name: { UserName},RedeemDate:{RedeemDate},Expirary Date{ExpiryDate},RedeemAmount:{RedeemAmount},productCode{ProductCode}" +
                
                $"";
        }

    }
}
