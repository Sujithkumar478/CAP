﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Reflection
{
    class Program
    {
        static void Main(string[] args)
        {

            //Extract meta data of Assembly-Reflection demo DLL,delegatedemo.exe
            Console.WriteLine("Enter path of any Assembly");
            string pathOfAsm = Console.ReadLine();
            Assembly asm = Assembly.LoadFrom(pathOfAsm);
            Type[] types = asm.GetTypes();
            foreach (Type t in types)
            {
                Console.WriteLine(t.FullName);
                MethodInfo[] methodInfo = t.GetMethods();
                foreach (MethodInfo m1 in methodInfo)  //methods info of the application
                {
                    Console.WriteLine(m1.ReturnType + " " + m1.Name + " " + "(" + ")");
                }

                PropertyInfo[] props = t.GetProperties();
                foreach (PropertyInfo p1 in props)      //property info of the application
                {
                    Console.WriteLine(p1.ToString());
                }
                Console.WriteLine("\n\tFields from " + t.Name);

                FieldInfo[] fis = t.GetFields();
                foreach (var f1 in fis)          //Field info of the application
                {
                    Console.WriteLine(f1.ToString());
                }
                Console.WriteLine("\n\t constructors from " + t.Name);
                ConstructorInfo[] cis = t.GetConstructors();
                foreach (var c1 in cis)          //constructor info of the application
                {
                    Console.WriteLine(c1.ToString());
                }



            }
        }
    }
}
