﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
{
    public delegate bool Mydel(string userName)
    class Program
    {
        


        static void Main(string[] args)
        {
            Coupoun cup = new Coupoun("Sujith");
            Mydel d1 = new Mydel(cup.GetCouponCodes);
            Console.WriteLine(d1("sujith"));
           

        }
        public bool GetCouponCodes(string UserName)
        {
            bool searchStringExists = Coupoun.Find(Coupoun => Coupoun.UserName == UserName)
                return searchStringExists;
        }

    }
}
