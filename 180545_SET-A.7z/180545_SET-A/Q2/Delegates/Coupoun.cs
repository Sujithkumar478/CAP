﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
{
    class Coupoun
    {
        public delegate bool Mydel(string userName)
        public string UserName { get; set; }
        Coupoun cup;
        public Coupoun(string userName)
        {
            bool SearchStringExists = false;
            if (cup.userName == userName)
            {
                SearchStringExists = true;

            }
            
        }
    }
}
