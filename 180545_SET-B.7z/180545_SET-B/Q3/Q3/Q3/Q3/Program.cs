﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Customer e = new Customer();

            //e.DisplayDetails(); //Invoke method DisplayDetails.

            //Console.ReadLine();

            ///Creating the object and calling
            Customer c = new Customer();

            c.Choice();


        }
    }
}
