﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Customer
    {

        /// <summary>
        /// Displaying the information particualr customer
        /// 8/05/2019
        /// </summary>
        //public int CustomerId { get; set; }
        //public string Customername { get; set; }
        //public long Contact { get; set; }
        //public string Email { get; set; }
        //public string Address { get; set; }
        //public string City { get; set; }


        //public Customer() //Default Constructor

        //{

        //}
        //// Prameterized Constructor

        //public Customer(int CustomerID, string CustomerName,  string Address,string city,long Contact,string Email) //Overloaded Constructor

        //{

        //    this.CustomerId = 1;

        //    this.Customername = "Sujith";

        //    this.Address = "Narsaraopet";

        //    this.City = "MUMBAI";
        //    this.Contact = 8790063064;
        //    this.Email = "sujith@gmail.com";

        //}
        //public void DisplayDetails() //Method Display Details to display details.

        //{

        //    Console.WriteLine("\n Details are as follows: \nCustomerID:"

        //    + CustomerId + "\nCustomer Name:" + Customername + "\nAddress:"

        //    + Address + "\n City :" + City+"\n Contact:"+Contact + "\n Email:"+Email );
        string CustomerName;

        int CustomerID, Contact;

        string Address, EmailID;





        List<Customer> lst = new List<Customer>();
        /// <summary>
        /// creaing the AddCustomer function 
        /// </summary>



        public void AddCustomer()

        {

            Customer cr = new Customer();







            Console.WriteLine("Enter Customer name");

            cr.CustomerName = Console.ReadLine();

            Console.WriteLine("Enter Customer ID:");

            cr.CustomerID = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Phone Number");

            cr.Contact = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Address");

            cr.Address = Console.ReadLine();

            Console.WriteLine("Enter email address");

            cr.EmailID = Console.ReadLine();

            lst.Add(cr);

            Choice();

        }



        public void displaylist()

        {

            if (lst.Count == 0 || lst == null)

            {

                Console.WriteLine("No records");

            }

            else

            {

                foreach (var cus in lst)

                {

                    Console.WriteLine("Customer Name" + cus.CustomerName);

                    Console.WriteLine("Customer ID" + cus.CustomerID);

                    Console.WriteLine("Customer phone number" + cus.Contact);

                    Console.WriteLine("Address" + cus.Address);

                    Console.WriteLine("Email ID" + EmailID);

                }

            }

            Choice();

        }



        public void Choice()

        {

            string choice;

            do

            {

                Console.WriteLine("\n***********Customer Details***********");

                Console.WriteLine("1. Add Customer");

                Console.WriteLine("2. Get all Customer Details");

                Console.WriteLine("Enter your choice");

                int ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)

                {

                    case 1:

                        AddCustomer();

                        break;

                    case 2:

                        displaylist();

                        break;

                }

                Console.WriteLine("Do you want to contiue(y/n)?");

                choice = Console.ReadLine();

            }

            while ((choice == "y"));

            Console.Read();



        }

    }

    }

