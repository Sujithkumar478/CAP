﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanyException
{
    public class Exceptionlayer:ApplicationException
    {
        //Default Constructor
        public Exceptionlayer() : base()
        { }

        //Parameterized Constructor to initialize Message property
        public Exceptionlayer(string message) : base(message)
        { }
    }
}
