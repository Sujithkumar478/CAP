﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CompanyEntityLayer;
using CompanyException;
using CompanyBLL;/// <summary>
/// Author:Sujith kumar
/// this is the presentation layer all layers are loaded to this layer
/// </summary>

namespace Q1
{
    class Program
    {
        public static void AddCustomer()
        {
            try
            {
                Entity customer = new Entity();
                Console.Write("Enter Cusytomer Id: ");
                customer.CustomerId = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Customer Name : ");
                customer.Customername = Console.ReadLine();
                Console.Write("Enter Address : ");
                customer.Address = Console.ReadLine();
                Console.Write("Enter city : ");
                customer.City = Console.ReadLine();
                Console.Write("Enter contact : ");
                customer.Contact =Convert.ToInt64(Console.ReadLine());

                Console.Write("Enter Email : ");
                customer.Email = Console.ReadLine();



                bool CustomerAdded = BLLayer.AddCustomer(customer);

                if (CustomerAdded)
                {
                    Console.WriteLine($"{customer.CustomerId} Customer name is {customer.Customername}");
                    Console.WriteLine(customer.Contact);
                    Console.WriteLine("customer  added successfully");
                }
                else
                {
                    throw new Exception("Employee not added");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            //catch (SystemException ex)
            //{
                //Console.WriteLine(ex.Message);
            //}
        }
        public static void PrintMenu()
        {
            Console.WriteLine("***********************");
            Console.WriteLine("1. Add  Customer ID:");
            //Console.WriteLine("2.Enter customer Name:");
            //Console.WriteLine("3.Enter customer Address:");
            //Console.WriteLine("4.Enter Customer City: ");
            //Console.WriteLine("5.Enter Customer Contact:");
            //Console.WriteLine("6.Enter Customer Email:");


        }
        static void Main(string[] args)
        {

            int choice;

            do
            {
                PrintMenu();
                Console.Write("Enter your choice : ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddCustomer();
                        break;
                    //break;
                    case 2:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Enter valid choice");
                        break;
                }
            } while (choice != 2);

            Console.ReadKey();

        }


            }
         }




    
