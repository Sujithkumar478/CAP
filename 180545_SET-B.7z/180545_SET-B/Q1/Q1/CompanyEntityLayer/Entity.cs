﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanyEntityLayer
{
    public class Entity
    {
        /// <summary>
        /// Intializing all the required details 
        /// </summary>
        public int CustomerId { get; set; }
        public string Customername { get; set; }
        public long Contact { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string City { get; set; }

    }
}
