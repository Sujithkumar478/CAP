﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CompanyEntityLayer;
using CompanyDAL;
using CompanyException;
using System.Text.RegularExpressions;

namespace CompanyBLL
{
    public class BLLayer
    {
        /// <summary>
        /// to validate the customer details we are checking
        /// </summary>
        /// <param name="customer"></param>
        /// <returns></returns>
        public static bool ValidateCustomer(Entity customer)
        {
            bool customerValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Checking - employee id should be 6 digit
                if ((customer.City != "Mumbai") && (customer.City != "Pune") && (customer.City != "Chennai") && (customer.City != "Delhi"))
                {
                    customerValidated = false;
                    message.Append(Environment.NewLine + "city should be Mumbai, Pune, Chennai, Delhi and in same format");
                }


                if (customer.CustomerId > 100000 || customer.Contact > 900000008)
                {
                    customerValidated = false;
                    message.Append("Customer  ID should be exactly 6 digits long\n");
                }
                //Checking - customer  name
                if (customer.Customername == String.Empty)
                {
                    customerValidated = false;
                    message.Append("customer Name should be provided\n");
                }
                else if (!Regex.IsMatch(customer.Customername, "[A-Z][a-z]{2,}"))
                {
                    customerValidated = false;
                    message.Append("customer Name should start with capital alphabet and it should have minimum 3 alphabets\n");
                }
            }
            catch (Exceptionlayer ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return customerValidated;
        }
        public static bool AddCustomer(Entity customer)
        {
            bool customerAdded = false;

            try
            {
                if (ValidateCustomer(customer))
                {
                    customerAdded = DALayer.AddCustomer(customer);
                }
                else
                {
                    throw new Exceptionlayer("Please provide valid data for customer");
                }

            }
            catch (Exceptionlayer ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return customerAdded;

        }
    }
}
