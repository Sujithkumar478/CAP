﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CompanyEntityLayer;
using CompanyException;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace CompanyDAL
{
    public class DALayer
    {
        static List<Entity> customerList = new List<Entity>();

        //To insert the customer record in customer list
        public static bool AddCustomer(Entity customer)
        {
            bool customerAdded = false;

            try
            {

                customerList.Add(customer);
                customerAdded = true;
            }
            catch (Exceptionlayer ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return customerAdded;
        }
        public static void SerializeData()
        {
            FileStream stream;
            try
            {
                stream = new FileStream(@"CUSTOMER.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, customerList);
                stream.Close();
            }
            catch (Exception e)
            {
                throw e;
            }

        }
        //deserializing data
        public static List<Entity> DeserializeData()
        {
            FileStream stream = new FileStream(@"Student.txt", FileMode.Open, FileAccess.Read);
            BinaryFormatter formatter = new BinaryFormatter();
            customerList = formatter.Deserialize(stream) as List<Entity>;
            return customerList;

        }
    }
}
