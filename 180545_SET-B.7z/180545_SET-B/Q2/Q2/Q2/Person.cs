﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Person
    {
        

        public string FirstName { get; set; }

        public string LastName { get; set; }
        //parameterised constructor
        public Person(string  FirstName, string LastName) 

        {

            this.FirstName = "RAM";

            this.LastName = "ROY";


        }
        public void displayDetails() //Method Display Details to display details.

        {

            Console.WriteLine("\n Details are as follows: \nID:"

            + FirstName + "\nName:" + LastName);

        }

       


    }
}
